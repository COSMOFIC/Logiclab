
'use client'

import { useMemo, useState } from 'react'

type GateType = 'SWITCH' | 'LED' | 'NOT' | 'AND' | 'OR' | 'NAND' | 'XOR'

type Component = {
  id: string
  type: GateType
  label: string
  state?: { value?: number }
}

type Wire = {
  id: string
  fromId: string
  toId: string
  toInput: 'A' | 'B' | 'IN'
}

function makeId() {
  return Math.random().toString(36).slice(2, 8)
}

function getInputsFor(type: GateType) {
  if (type === 'SWITCH') return []
  if (type === 'LED') return ['IN'] as const
  if (type === 'NOT') return ['A'] as const
  return ['A', 'B'] as const
}

function computeGate(type: GateType, a: number, b: number) {
  switch (type) {
    case 'SWITCH':
      return a
    case 'NOT':
      return a === 1 ? 0 : 1
    case 'AND':
      return a === 1 && b === 1 ? 1 : 0
    case 'OR':
      return a === 1 || b === 1 ? 1 : 0
    case 'NAND':
      return a === 1 && b === 1 ? 0 : 1
    case 'XOR':
      return a !== b ? 1 : 0
    default:
      return 0
  }
}

function simulate(components: Component[], wires: Wire[]) {
  const outputs: Record<string, number> = {}

  components.forEach((component) => {
    if (component.type === 'SWITCH') {
      outputs[component.id] = component.state?.value ?? 0
    }
  })

  for (let pass = 0; pass < 8; pass++) {
    components.forEach((component) => {
      if (component.type === 'SWITCH') return

      const inputMap: Record<string, number> = { A: 0, B: 0, IN: 0 }

      wires
        .filter((wire) => wire.toId === component.id)
        .forEach((wire) => {
          inputMap[wire.toInput] = outputs[wire.fromId] ?? 0
        })

      if (component.type === 'LED') {
        outputs[component.id] = inputMap.IN
      } else if (component.type === 'NOT') {
        outputs[component.id] = computeGate(component.type, inputMap.A, 0)
      } else {
        outputs[component.id] = computeGate(component.type, inputMap.A, inputMap.B)
      }
    })
  }

  return outputs
}

export default function SimulatorWorkspace() {
  const [components, setComponents] = useState<Component[]>([
    { id: 'sw1', type: 'SWITCH', label: 'Switch 1', state: { value: 0 } },
    { id: 'g1', type: 'NAND', label: 'NAND 1' },
    { id: 'led1', type: 'LED', label: 'LED 1' }
  ])

  const [wires, setWires] = useState<Wire[]>([
    { id: 'w1', fromId: 'sw1', toId: 'g1', toInput: 'A' },
    { id: 'w2', fromId: 'sw1', toId: 'g1', toInput: 'B' },
    { id: 'w3', fromId: 'g1', toId: 'led1', toInput: 'IN' }
  ])

  const [newType, setNewType] = useState<GateType>('NAND')
  const [fromId, setFromId] = useState('')
  const [toId, setToId] = useState('')
  const [toInput, setToInput] = useState<'A' | 'B' | 'IN'>('A')

  const outputs = useMemo(() => simulate(components, wires), [components, wires])

  const addComponent = () => {
    const id = makeId()
    const count = components.filter((c) => c.type === newType).length + 1
    setComponents((prev) => [
      ...prev,
      {
        id,
        type: newType,
        label: `${newType} ${count}`,
        state: newType === 'SWITCH' ? { value: 0 } : undefined
      }
    ])
  }

  const addWire = () => {
    if (!fromId || !toId || fromId === toId) return
    const target = components.find((c) => c.id === toId)
    if (!target || target.type === 'SWITCH') return

    const allowedInputs = getInputsFor(target.type)
    const finalInput = allowedInputs.includes(toInput as any) ? toInput : allowedInputs[0]

    const duplicate = wires.some(
      (wire) => wire.fromId === fromId && wire.toId === toId && wire.toInput === finalInput
    )
    if (duplicate) return

    setWires((prev) => [
      ...prev,
      {
        id: makeId(),
        fromId,
        toId,
        toInput: finalInput
      }
    ])
  }

  const removeWire = (id: string) => {
    setWires((prev) => prev.filter((wire) => wire.id !== id))
  }

  const removeComponent = (id: string) => {
    setComponents((prev) => prev.filter((c) => c.id !== id))
    setWires((prev) => prev.filter((w) => w.fromId !== id && w.toId !== id))
  }

  const toggleSwitch = (id: string) => {
    setComponents((prev) =>
      prev.map((component) =>
        component.id === id
          ? {
              ...component,
              state: {
                value: component.state?.value === 1 ? 0 : 1
              }
            }
          : component
      )
    )
  }

  const sourceOptions = components.filter((c) => c.type !== 'LED')
  const targetOptions = components.filter((c) => c.type !== 'SWITCH')

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
        <h2 className="text-2xl font-semibold">Circuit Builder v1</h2>
        <p className="mt-2 text-sm text-slate-400">
          Add components, connect outputs to inputs, and simulate simple logic circuits.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        <div className="space-y-6">
          <div className="rounded-2xl border border-white/10 bg-slate-900 p-5">
            <h3 className="text-lg font-semibold">Add Component</h3>

            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value as GateType)}
              className="mt-4 w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3"
            >
              <option value="SWITCH">Switch</option>
              <option value="LED">LED</option>
              <option value="NOT">NOT</option>
              <option value="AND">AND</option>
              <option value="OR">OR</option>
              <option value="NAND">NAND</option>
              <option value="XOR">XOR</option>
            </select>

            <button
              onClick={addComponent}
              className="mt-4 w-full rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
            >
              Add Component
            </button>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900 p-5">
            <h3 className="text-lg font-semibold">Connect Wire</h3>

            <div className="mt-4 space-y-3">
              <select
                value={fromId}
                onChange={(e) => setFromId(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3"
              >
                <option value="">From output...</option>
                {sourceOptions.map((component) => (
                  <option key={component.id} value={component.id}>
                    {component.label}
                  </option>
                ))}
              </select>

              <select
                value={toId}
                onChange={(e) => setToId(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3"
              >
                <option value="">To component...</option>
                {targetOptions.map((component) => (
                  <option key={component.id} value={component.id}>
                    {component.label}
                  </option>
                ))}
              </select>

              <select
                value={toInput}
                onChange={(e) => setToInput(e.target.value as 'A' | 'B' | 'IN')}
                className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3"
              >
                <option value="A">Input A</option>
                <option value="B">Input B</option>
                <option value="IN">Input IN</option>
              </select>

              <button
                onClick={addWire}
                className="w-full rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
              >
                Create Connection
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900 p-5">
            <h3 className="text-lg font-semibold">Connections</h3>
            <div className="mt-4 space-y-2">
              {wires.length === 0 && <p className="text-sm text-slate-400">No wires yet.</p>}
              {wires.map((wire) => (
                <div
                  key={wire.id}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm"
                >
                  <span>
                    {wire.fromId} → {wire.toId}.{wire.toInput}
                  </span>
                  <button
                    onClick={() => removeWire(wire.id)}
                    className="rounded-lg bg-rose-500/20 px-2 py-1 text-xs text-rose-300"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h3 className="text-lg font-semibold">Workspace</h3>
          <p className="mt-2 text-sm text-slate-400">
            This is the first circuit builder version. Each block shows its live output.
          </p>

          <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {components.map((component) => {
              const out = outputs[component.id] ?? 0

              return (
                <div
                  key={component.id}
                  className="rounded-2xl border border-white/10 bg-slate-950 p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs text-slate-500">{component.id}</p>
                      <h4 className="mt-1 font-semibold">{component.label}</h4>
                    </div>

                    <button
                      onClick={() => removeComponent(component.id)}
                      className="rounded-lg bg-rose-500/20 px-2 py-1 text-xs text-rose-300"
                    >
                      Delete
                    </button>
                  </div>

                  <div className="mt-4 space-y-3">
                    <div className="rounded-xl border border-white/10 bg-slate-900 px-3 py-2 text-sm">
                      Type: {component.type}
                    </div>

                    {component.type === 'SWITCH' && (
                      <button
                        onClick={() => toggleSwitch(component.id)}
                        className="w-full rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
                      >
                        Toggle: {component.state?.value ?? 0}
                      </button>
                    )}

                    <div className="rounded-xl border border-white/10 bg-slate-900 px-3 py-3">
                      <p className="text-xs text-slate-500">Output</p>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="font-semibold">Y = {out}</span>
                        <div
                          className={`h-4 w-4 rounded-full ${
                            out === 1 ? 'bg-emerald-400 shadow-lg shadow-emerald-400/40' : 'bg-slate-600'
                          }`}
                        />
                      </div>
                    </div>

                    {component.type !== 'SWITCH' && (
                      <div className="rounded-xl border border-white/10 bg-slate-900 px-3 py-3 text-xs text-slate-400">
                        Inputs: {getInputsFor(component.type).join(', ')}
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
