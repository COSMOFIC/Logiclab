
export const chipData: Record<
  string,
  {
    name: string
    title: string
    description: string
    truthTable: { A: number; B: number; Y: number }[]
    pinsLeft: string[]
    pinsRight: string[]
  }
> = {
  "7400": {
    name: "7400",
    title: "Quad 2‑Input NAND Gate",
    description:
      "The 7400 contains four independent NAND gates. NAND is called a universal gate because you can build all other basic logic gates from it.",
    truthTable: [
      { A: 0, B: 0, Y: 1 },
      { A: 0, B: 1, Y: 1 },
      { A: 1, B: 0, Y: 1 },
      { A: 1, B: 1, Y: 0 }
    ],
    pinsLeft: ["1 A1","2 B1","3 Y1","4 A2","5 B2","6 Y2","7 GND"],
    pinsRight: ["14 VCC","13 B4","12 A4","11 Y4","10 B3","9 A3","8 Y3"]
  },

  "7404": {
    name: "7404",
    title: "Hex Inverter",
    description: "The 7404 contains six NOT gates. Each output is the opposite of its input.",
    truthTable: [
      { A: 0, B: 0, Y: 1 },
      { A: 1, B: 1, Y: 0 }
    ],
    pinsLeft: ["1 A1","2 Y1","3 A2","4 Y2","5 A3","6 Y3","7 GND"],
    pinsRight: ["14 VCC","13 A6","12 Y6","11 A5","10 Y5","9 A4","8 Y4"]
  }
}
