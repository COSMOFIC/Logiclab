
import { chipData } from "@/lib/content/chips"

export default function ChipPage({ params }: { params: { slug: string } }) {
  const chip = chipData[params.slug]

  if (!chip) {
    return (
      <section style={{padding:40}}>
        <h1>Chip not found</h1>
      </section>
    )
  }

  return (
    <section style={{padding:40}}>
      <h1>{chip.name}</h1>
      <h3>{chip.title}</h3>
      <p>{chip.description}</p>

      <h2 style={{marginTop:30}}>Truth Table</h2>
      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>A</th>
            <th>B</th>
            <th>Y</th>
          </tr>
        </thead>
        <tbody>
          {chip.truthTable.map((row, i) => (
            <tr key={i}>
              <td>{row.A}</td>
              <td>{row.B}</td>
              <td>{row.Y}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  )
}
