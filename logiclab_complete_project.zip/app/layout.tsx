
import './globals.css'
import Link from 'next/link'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-white">
        <nav className="border-b border-white/10">
          <div className="mx-auto max-w-6xl px-6 py-4 flex gap-6">
            <Link href="/">LogicLab</Link>
            <Link href="/simulator">Simulator</Link>
            <Link href="/chips">Chips</Link>
            <Link href="/challenges">Challenges</Link>
            <Link href="/learn">Learn</Link>
            <Link href="/fab">Fab Lab</Link>
            <Link href="/dashboard">Dashboard</Link>
            <Link href="/campaign">Campaign</Link>
          </div>
        </nav>
        <main>{children}</main>
      </body>
    </html>
  )
}
