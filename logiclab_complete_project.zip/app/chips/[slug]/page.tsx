
export default function ChipPage({ params }: { params: { slug: string } }) {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Chip {params.slug}</h1>
      <p className="mt-4 text-slate-300">
        Chip learning page placeholder.
      </p>
    </section>
  )
}
