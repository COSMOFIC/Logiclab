
import Link from 'next/link'

const chips = [
  { slug: '7400', name: '7400 NAND' },
  { slug: '7404', name: '7404 NOT' },
  { slug: '7408', name: '7408 AND' },
  { slug: '7432', name: '7432 OR' },
  { slug: '7486', name: '7486 XOR' }
]

export default function ChipsPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Chip Library</h1>

      <div className="grid grid-cols-2 gap-4 mt-6">
        {chips.map(c => (
          <Link
            key={c.slug}
            href={`/chips/${c.slug}`}
            className="border border-white/10 rounded p-4"
          >
            {c.name}
          </Link>
        ))}
      </div>
    </section>
  )
}
