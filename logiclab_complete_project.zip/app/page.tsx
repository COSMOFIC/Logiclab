
import Link from 'next/link'

export default function HomePage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-16">
      <h1 className="text-4xl font-bold">LogicLab</h1>
      <p className="mt-4 text-slate-300">
        Interactive digital electronics learning platform.
      </p>
      <div className="mt-8 flex gap-4">
        <Link href="/simulator" className="rounded-xl bg-cyan-400 px-4 py-2 text-slate-950">
          Open Simulator
        </Link>
        <Link href="/chips" className="rounded-xl border border-white/20 px-4 py-2">
          Explore Chips
        </Link>
      </div>
    </section>
  )
}
