
import SimulatorWorkspace from '@/components/simulator/workspace'

export default function SimulatorPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Circuit Simulator</h1>
      <div className="mt-6">
        <SimulatorWorkspace />
      </div>
    </section>
  )
}
