
export default function DashboardPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      <p className="mt-4 text-slate-300">
        User progress and saved circuits.
      </p>
    </section>
  )
}
