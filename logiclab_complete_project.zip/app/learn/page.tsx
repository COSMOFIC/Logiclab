
export default function LearnPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Learning Paths</h1>
    </section>
  )
}
