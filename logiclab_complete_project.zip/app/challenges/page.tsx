
export default function ChallengesPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Challenges</h1>
      <p className="mt-4 text-slate-300">
        Build circuits and earn XP.
      </p>
    </section>
  )
}
