
export default function CampaignPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">LogicLab Campaign</h1>
      <p className="mt-4 text-slate-300">
        Help fund the development of LogicLab.
      </p>
    </section>
  )
}
