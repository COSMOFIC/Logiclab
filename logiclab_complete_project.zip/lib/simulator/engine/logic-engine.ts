
export function simulateCircuit(circuit: any) {
  return {}
}
