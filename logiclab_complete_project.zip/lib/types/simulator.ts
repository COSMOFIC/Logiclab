
export interface CircuitComponent {
  id: string
  type: string
  inputs: string[]
  outputs: string[]
}
