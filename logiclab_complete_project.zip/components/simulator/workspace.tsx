
'use client'
import { useState } from 'react'

export default function SimulatorWorkspace() {
  const [value, setValue] = useState(0)

  return (
    <div className="border border-white/10 rounded-xl p-6 bg-slate-900">
      <p className="mb-4">Basic simulator demo</p>

      <button
        onClick={() => setValue(value ? 0 : 1)}
        className="bg-cyan-400 text-black px-4 py-2 rounded"
      >
        Toggle Switch
      </button>

      <div className="mt-4">
        LED Output: {value}
      </div>
    </div>
  )
}
