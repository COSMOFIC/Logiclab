
'use client'

import { useMemo, useRef, useState } from 'react'

type GateType = 'NOT' | 'AND' | 'OR' | 'NAND' | 'XOR'
type NodeKey = 'switchA' | 'switchB' | 'gate' | 'led'

type Pos = { x: number; y: number }
type Positions = Record<NodeKey, Pos>

const NODE_W = {
  switchA: 120,
  switchB: 120,
  gate: 180,
  led: 120
}

const NODE_H = {
  switchA: 90,
  switchB: 90,
  gate: 130,
  led: 90
}

export default function SimulatorWorkspace() {
  const canvasRef = useRef<HTMLDivElement | null>(null)

  const [gate, setGate] = useState<GateType>('NAND')
  const [a, setA] = useState(0)
  const [b, setB] = useState(0)

  const [positions, setPositions] = useState<Positions>({
    switchA: { x: 24, y: 40 },
    switchB: { x: 24, y: 180 },
    gate: { x: 290, y: 95 },
    led: { x: 560, y: 120 }
  })

  const [dragging, setDragging] = useState<{
    key: NodeKey
    offsetX: number
    offsetY: number
  } | null>(null)

  const y = useMemo(() => {
    if (gate === 'NOT') return a === 1 ? 0 : 1
    if (gate === 'AND') return a === 1 && b === 1 ? 1 : 0
    if (gate === 'OR') return a === 1 || b === 1 ? 1 : 0
    if (gate === 'NAND') return a === 1 && b === 1 ? 0 : 1
    return a !== b ? 1 : 0
  }, [gate, a, b])

  const gateDescription =
    gate === 'NOT'
      ? 'NOT flips input A.'
      : gate === 'AND'
      ? 'AND outputs 1 only when both inputs are 1.'
      : gate === 'OR'
      ? 'OR outputs 1 when at least one input is 1.'
      : gate === 'NAND'
      ? 'NAND outputs 0 only when both inputs are 1.'
      : 'XOR outputs 1 when the two inputs are different.'

  function clamp(n: number, min: number, max: number) {
    return Math.max(min, Math.min(max, n))
  }

  function getCanvasPoint(e: React.PointerEvent) {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return { x: 0, y: 0 }
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    }
  }

  function startDrag(key: NodeKey, e: React.PointerEvent) {
    const p = getCanvasPoint(e)
    const pos = positions[key]
    setDragging({
      key,
      offsetX: p.x - pos.x,
      offsetY: p.y - pos.y
    })
  }

  function moveDrag(e: React.PointerEvent) {
    if (!dragging || !canvasRef.current) return

    const rect = canvasRef.current.getBoundingClientRect()
    const p = getCanvasPoint(e)

    const maxX = rect.width - (NODE_W[dragging.key] as number) - 12
    const maxY = rect.height - (NODE_H[dragging.key] as number) - 12

    setPositions((prev) => ({
      ...prev,
      [dragging.key]: {
        x: clamp(p.x - dragging.offsetX, 12, maxX),
        y: clamp(p.y - dragging.offsetY, 12, maxY)
      }
    }))
  }

  function endDrag() {
    setDragging(null)
  }

  const lineA = {
    x1: positions.switchA.x + 120,
    y1: positions.switchA.y + 45,
    x2: positions.gate.x,
    y2: positions.gate.y + 40
  }

  const lineB = {
    x1: positions.switchB.x + 120,
    y1: positions.switchB.y + 45,
    x2: positions.gate.x,
    y2: positions.gate.y + 92
  }

  const lineOut = {
    x1: positions.gate.x + 180,
    y1: positions.gate.y + 65,
    x2: positions.led.x,
    y2: positions.led.y + 45
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
        <h2 className="text-2xl font-semibold">Drag & Drop Logic Simulator</h2>
        <p className="mt-2 text-sm text-slate-400">
          Drag the blocks around the canvas. Toggle the inputs and watch the selected gate drive the LED output.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div className="rounded-2xl border border-white/10 bg-slate-900 p-5">
          <h3 className="text-lg font-semibold">Choose Gate</h3>

          <div className="mt-4 grid gap-3">
            {(['NOT', 'AND', 'OR', 'NAND', 'XOR'] as GateType[]).map((item) => (
              <button
                key={item}
                onClick={() => setGate(item)}
                className={`rounded-xl border px-4 py-3 text-left transition ${
                  gate === item
                    ? 'border-cyan-400 bg-cyan-400 text-slate-950'
                    : 'border-white/10 bg-slate-950 text-white hover:bg-slate-800'
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          <div className="mt-6 rounded-xl border border-white/10 bg-slate-950 p-4">
            <p className="text-sm text-slate-400">Current rule</p>
            <p className="mt-2 text-sm text-slate-300">{gateDescription}</p>
          </div>

          <div className="mt-6 grid gap-3">
            <button
              onClick={() => setA(a ? 0 : 1)}
              className="rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
            >
              Toggle A = {a}
            </button>

            <button
              onClick={() => setB(b ? 0 : 1)}
              disabled={gate === 'NOT'}
              className={`rounded-xl px-4 py-3 font-semibold ${
                gate === 'NOT'
                  ? 'cursor-not-allowed bg-slate-800 text-slate-500'
                  : 'bg-cyan-400 text-slate-950'
              }`}
            >
              {gate === 'NOT' ? 'B not used' : `Toggle B = ${b}`}
            </button>
          </div>

          <div className="mt-6 rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-4">
            <p className="text-xs text-emerald-300">Live Output</p>
            <p className="mt-2 text-2xl font-bold">{y}</p>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h3 className="text-lg font-semibold">Canvas</h3>
          <p className="mt-2 text-sm text-slate-400">
            Press and drag any block. The wire lines follow automatically.
          </p>

          <div
            ref={canvasRef}
            onPointerMove={moveDrag}
            onPointerUp={endDrag}
            onPointerLeave={endDrag}
            className="relative mt-6 h-[560px] overflow-hidden rounded-2xl border border-white/10 bg-slate-950"
            style={{
              backgroundImage:
                'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.08) 1px, transparent 0)',
              backgroundSize: '24px 24px'
            }}
          >
            <svg className="pointer-events-none absolute inset-0 h-full w-full">
              <line
                x1={lineA.x1}
                y1={lineA.y1}
                x2={lineA.x2}
                y2={lineA.y2}
                stroke="#22d3ee"
                strokeWidth="4"
              />
              {gate !== 'NOT' && (
                <line
                  x1={lineB.x1}
                  y1={lineB.y1}
                  x2={lineB.x2}
                  y2={lineB.y2}
                  stroke="#22d3ee"
                  strokeWidth="4"
                />
              )}
              <line
                x1={lineOut.x1}
                y1={lineOut.y1}
                x2={lineOut.x2}
                y2={lineOut.y2}
                stroke="#22d3ee"
                strokeWidth="4"
              />
            </svg>

            <div
              onPointerDown={(e) => startDrag('switchA', e)}
              className="absolute rounded-2xl border border-white/10 bg-slate-900 p-4 text-center shadow-lg touch-none"
              style={{
                left: positions.switchA.x,
                top: positions.switchA.y,
                width: NODE_W.switchA,
                height: NODE_H.switchA
              }}
            >
              <p className="text-xs text-slate-500">Switch A</p>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setA(a ? 0 : 1)
                }}
                className="mt-3 w-full rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
              >
                {a}
              </button>
            </div>

            <div
              onPointerDown={(e) => startDrag('switchB', e)}
              className="absolute rounded-2xl border border-white/10 bg-slate-900 p-4 text-center shadow-lg touch-none"
              style={{
                left: positions.switchB.x,
                top: positions.switchB.y,
                width: NODE_W.switchB,
                height: NODE_H.switchB
              }}
            >
              <p className="text-xs text-slate-500">Switch B</p>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  if (gate !== 'NOT') setB(b ? 0 : 1)
                }}
                className={`mt-3 w-full rounded-xl px-4 py-3 font-semibold ${
                  gate === 'NOT'
                    ? 'cursor-not-allowed bg-slate-800 text-slate-500'
                    : 'bg-cyan-400 text-slate-950'
                }`}
              >
                {gate === 'NOT' ? '-' : b}
              </button>
            </div>

            <div
              onPointerDown={(e) => startDrag('gate', e)}
              className="absolute rounded-2xl border border-cyan-400/20 bg-cyan-400/5 p-6 text-center shadow-lg touch-none"
              style={{
                left: positions.gate.x,
                top: positions.gate.y,
                width: NODE_W.gate,
                height: NODE_H.gate
              }}
            >
              <p className="text-sm text-cyan-200">Selected Gate</p>
              <p className="mt-2 text-3xl font-bold">{gate}</p>
              <div className="mt-4 rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-300">
                A = {a} {gate === 'NOT' ? '' : `• B = ${b}`}
              </div>
            </div>

            <div
              onPointerDown={(e) => startDrag('led', e)}
              className="absolute rounded-2xl border border-white/10 bg-slate-900 p-4 text-center shadow-lg touch-none"
              style={{
                left: positions.led.x,
                top: positions.led.y,
                width: NODE_W.led,
                height: NODE_H.led
              }}
            >
              <p className="text-xs text-slate-500">LED Output</p>
              <div className="mt-3 flex items-center justify-center gap-3">
                <div
                  className={`h-5 w-5 rounded-full ${
                    y === 1 ? 'bg-emerald-400 shadow-lg shadow-emerald-400/50' : 'bg-slate-600'
                  }`}
                />
                <span className="text-2xl font-bold">{y}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-xs text-slate-500">Input A</p>
              <p className="mt-2 text-2xl font-bold">{a}</p>
            </div>

            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-xs text-slate-500">Input B</p>
              <p className="mt-2 text-2xl font-bold">{gate === 'NOT' ? '-' : b}</p>
            </div>

            <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-4">
              <p className="text-xs text-emerald-300">Output Y</p>
              <p className="mt-2 text-2xl font-bold">{y}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
