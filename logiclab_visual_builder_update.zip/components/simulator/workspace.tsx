
'use client'

import { useMemo, useState } from 'react'

type GateType = 'NOT' | 'AND' | 'OR' | 'NAND' | 'XOR'

export default function SimulatorWorkspace() {
  const [gate, setGate] = useState<GateType>('NAND')
  const [a, setA] = useState(0)
  const [b, setB] = useState(0)

  const y = useMemo(() => {
    if (gate === 'NOT') return a === 1 ? 0 : 1
    if (gate === 'AND') return a === 1 && b === 1 ? 1 : 0
    if (gate === 'OR') return a === 1 || b === 1 ? 1 : 0
    if (gate === 'NAND') return a === 1 && b === 1 ? 0 : 1
    return a !== b ? 1 : 0
  }, [gate, a, b])

  const gateDescription =
    gate === 'NOT'
      ? 'NOT flips input A.'
      : gate === 'AND'
      ? 'AND outputs 1 only when both inputs are 1.'
      : gate === 'OR'
      ? 'OR outputs 1 when at least one input is 1.'
      : gate === 'NAND'
      ? 'NAND outputs 0 only when both inputs are 1.'
      : 'XOR outputs 1 when the two inputs are different.'

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
        <h2 className="text-2xl font-semibold">Visual Logic Simulator</h2>
        <p className="mt-2 text-sm text-slate-400">
          A cleaner visual simulator for phone and desktop. Toggle inputs and watch the gate and LED update live.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div className="rounded-2xl border border-white/10 bg-slate-900 p-5">
          <h3 className="text-lg font-semibold">Choose Gate</h3>

          <div className="mt-4 grid gap-3">
            {(['NOT', 'AND', 'OR', 'NAND', 'XOR'] as GateType[]).map((item) => (
              <button
                key={item}
                onClick={() => setGate(item)}
                className={`rounded-xl border px-4 py-3 text-left transition ${
                  gate === item
                    ? 'border-cyan-400 bg-cyan-400 text-slate-950'
                    : 'border-white/10 bg-slate-950 text-white hover:bg-slate-800'
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          <div className="mt-6 rounded-xl border border-white/10 bg-slate-950 p-4">
            <p className="text-sm text-slate-400">Current rule</p>
            <p className="mt-2 text-sm text-slate-300">{gateDescription}</p>
          </div>

          <div className="mt-6 grid gap-3">
            <button
              onClick={() => setA(a ? 0 : 1)}
              className="rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
            >
              Toggle A = {a}
            </button>

            <button
              onClick={() => setB(b ? 0 : 1)}
              disabled={gate === 'NOT'}
              className={`rounded-xl px-4 py-3 font-semibold ${
                gate === 'NOT'
                  ? 'cursor-not-allowed bg-slate-800 text-slate-500'
                  : 'bg-cyan-400 text-slate-950'
              }`}
            >
              {gate === 'NOT' ? 'B not used' : `Toggle B = ${b}`}
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h3 className="text-lg font-semibold">Workspace</h3>
          <p className="mt-2 text-sm text-slate-400">
            This is a visual fixed-layout circuit. Input switches feed the selected gate, and the result drives the LED.
          </p>

          <div className="mt-6 overflow-x-auto">
            <div className="relative min-w-[680px] rounded-2xl border border-white/10 bg-slate-950 p-6">
              <svg
                viewBox="0 0 680 260"
                className="absolute inset-0 h-full w-full"
                aria-hidden="true"
              >
                <line x1="150" y1="85" x2="295" y2="85" stroke="#22d3ee" strokeWidth="4" />
                {gate !== 'NOT' && (
                  <line x1="150" y1="175" x2="295" y2="175" stroke="#22d3ee" strokeWidth="4" />
                )}
                <line x1="425" y1="130" x2="545" y2="130" stroke="#22d3ee" strokeWidth="4" />
              </svg>

              <div className="relative flex min-h-[220px] items-center justify-between gap-6">
                <div className="flex flex-col gap-6">
                  <div className="w-[120px] rounded-2xl border border-white/10 bg-slate-900 p-4 text-center">
                    <p className="text-xs text-slate-500">Switch A</p>
                    <button
                      onClick={() => setA(a ? 0 : 1)}
                      className="mt-3 w-full rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
                    >
                      {a}
                    </button>
                  </div>

                  <div className="w-[120px] rounded-2xl border border-white/10 bg-slate-900 p-4 text-center">
                    <p className="text-xs text-slate-500">Switch B</p>
                    <button
                      onClick={() => setB(b ? 0 : 1)}
                      disabled={gate === 'NOT'}
                      className={`mt-3 w-full rounded-xl px-4 py-3 font-semibold ${
                        gate === 'NOT'
                          ? 'cursor-not-allowed bg-slate-800 text-slate-500'
                          : 'bg-cyan-400 text-slate-950'
                      }`}
                    >
                      {gate === 'NOT' ? '-' : b}
                    </button>
                  </div>
                </div>

                <div className="w-[180px] rounded-2xl border border-cyan-400/20 bg-cyan-400/5 p-6 text-center">
                  <p className="text-sm text-cyan-200">Selected Gate</p>
                  <p className="mt-2 text-3xl font-bold">{gate}</p>
                  <div className="mt-4 rounded-xl border border-white/10 bg-slate-900 px-4 py-3 text-sm text-slate-300">
                    A = {a} {gate === 'NOT' ? '' : `• B = ${b}`}
                  </div>
                </div>

                <div className="w-[120px] rounded-2xl border border-white/10 bg-slate-900 p-4 text-center">
                  <p className="text-xs text-slate-500">LED Output</p>
                  <div className="mt-3 flex items-center justify-center gap-3">
                    <div
                      className={`h-5 w-5 rounded-full ${
                        y === 1 ? 'bg-emerald-400 shadow-lg shadow-emerald-400/50' : 'bg-slate-600'
                      }`}
                    />
                    <span className="text-2xl font-bold">{y}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-xs text-slate-500">Input A</p>
              <p className="mt-2 text-2xl font-bold">{a}</p>
            </div>

            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-xs text-slate-500">Input B</p>
              <p className="mt-2 text-2xl font-bold">{gate === 'NOT' ? '-' : b}</p>
            </div>

            <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-4">
              <p className="text-xs text-emerald-300">Output Y</p>
              <p className="mt-2 text-2xl font-bold">{y}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
