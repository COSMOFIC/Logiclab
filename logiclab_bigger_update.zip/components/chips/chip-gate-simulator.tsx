
'use client'

import { useMemo, useState } from 'react'

function compute(type: string, a: number, b: number) {
  switch (type) {
    case 'NAND':
      return a === 1 && b === 1 ? 0 : 1
    case 'AND':
      return a === 1 && b === 1 ? 1 : 0
    case 'OR':
      return a === 1 || b === 1 ? 1 : 0
    case 'XOR':
      return a !== b ? 1 : 0
    case 'NOT':
      return a === 1 ? 0 : 1
    default:
      return 0
  }
}

export default function ChipGateSimulator({
  type
}: {
  type: 'NAND' | 'NOT' | 'AND' | 'OR' | 'XOR'
}) {
  const [a, setA] = useState(0)
  const [b, setB] = useState(0)

  const y = useMemo(() => compute(type, a, b), [type, a, b])

  return (
    <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
      <h2 className="text-xl font-semibold">Interactive Gate Simulator</h2>
      <p className="mt-2 text-sm text-slate-400">
        Toggle the inputs and see how the output changes.
      </p>

      <div className="mt-6 flex flex-wrap items-center gap-4">
        <button
          onClick={() => setA(a ? 0 : 1)}
          className="rounded-xl bg-cyan-400 px-4 py-2 text-slate-950"
        >
          A = {a}
        </button>

        {type !== 'NOT' && (
          <button
            onClick={() => setB(b ? 0 : 1)}
            className="rounded-xl bg-cyan-400 px-4 py-2 text-slate-950"
          >
            B = {b}
          </button>
        )}

        <div className="rounded-xl border border-white/10 bg-slate-950 px-4 py-2">
          Y = {y}
        </div>
      </div>

      <div className="mt-6 rounded-xl border border-white/10 bg-slate-950 p-4">
        <p className="text-sm text-slate-300">
          Gate type: <span className="font-semibold text-white">{type}</span>
        </p>
      </div>
    </div>
  )
}
