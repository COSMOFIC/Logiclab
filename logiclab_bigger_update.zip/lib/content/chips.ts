
export type ChipKey = "7400" | "7404" | "7408" | "7432" | "7486"

export const chipData: Record<
  string,
  {
    name: string
    title: string
    description: string
    truthTable: { A: number; B?: number; Y: number }[]
    pinsLeft: string[]
    pinsRight: string[]
    simulatorType: "NAND" | "NOT" | "AND" | "OR" | "XOR"
  }
> = {
  "7400": {
    name: "7400",
    title: "Quad 2-Input NAND Gate",
    description:
      "The 7400 contains four independent NAND gates. NAND is a universal gate because you can build all other basic logic gates from it.",
    truthTable: [
      { A: 0, B: 0, Y: 1 },
      { A: 0, B: 1, Y: 1 },
      { A: 1, B: 0, Y: 1 },
      { A: 1, B: 1, Y: 0 }
    ],
    pinsLeft: ["1 A1","2 B1","3 Y1","4 A2","5 B2","6 Y2","7 GND"],
    pinsRight: ["14 VCC","13 B4","12 A4","11 Y4","10 B3","9 A3","8 Y3"],
    simulatorType: "NAND"
  },
  "7404": {
    name: "7404",
    title: "Hex Inverter",
    description:
      "The 7404 contains six NOT gates. Each inverter outputs the opposite of its input.",
    truthTable: [
      { A: 0, Y: 1 },
      { A: 1, Y: 0 }
    ],
    pinsLeft: ["1 A1","2 Y1","3 A2","4 Y2","5 A3","6 Y3","7 GND"],
    pinsRight: ["14 VCC","13 A6","12 Y6","11 A5","10 Y5","9 A4","8 Y4"],
    simulatorType: "NOT"
  },
  "7408": {
    name: "7408",
    title: "Quad 2-Input AND Gate",
    description:
      "The 7408 contains four independent AND gates. Output is HIGH only when both inputs are HIGH.",
    truthTable: [
      { A: 0, B: 0, Y: 0 },
      { A: 0, B: 1, Y: 0 },
      { A: 1, B: 0, Y: 0 },
      { A: 1, B: 1, Y: 1 }
    ],
    pinsLeft: ["1 A1","2 B1","3 Y1","4 A2","5 B2","6 Y2","7 GND"],
    pinsRight: ["14 VCC","13 B4","12 A4","11 Y4","10 B3","9 A3","8 Y3"],
    simulatorType: "AND"
  },
  "7432": {
    name: "7432",
    title: "Quad 2-Input OR Gate",
    description:
      "The 7432 contains four independent OR gates. Output is HIGH if either input is HIGH.",
    truthTable: [
      { A: 0, B: 0, Y: 0 },
      { A: 0, B: 1, Y: 1 },
      { A: 1, B: 0, Y: 1 },
      { A: 1, B: 1, Y: 1 }
    ],
    pinsLeft: ["1 A1","2 B1","3 Y1","4 A2","5 B2","6 Y2","7 GND"],
    pinsRight: ["14 VCC","13 B4","12 A4","11 Y4","10 B3","9 A3","8 Y3"],
    simulatorType: "OR"
  },
  "7486": {
    name: "7486",
    title: "Quad 2-Input XOR Gate",
    description:
      "The 7486 contains four independent XOR gates. Output is HIGH when the inputs are different.",
    truthTable: [
      { A: 0, B: 0, Y: 0 },
      { A: 0, B: 1, Y: 1 },
      { A: 1, B: 0, Y: 1 },
      { A: 1, B: 1, Y: 0 }
    ],
    pinsLeft: ["1 A1","2 B1","3 Y1","4 A2","5 B2","6 Y2","7 GND"],
    pinsRight: ["14 VCC","13 B4","12 A4","11 Y4","10 B3","9 A3","8 Y3"],
    simulatorType: "XOR"
  }
}
