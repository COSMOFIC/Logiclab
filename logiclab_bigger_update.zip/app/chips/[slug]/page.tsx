
import Link from "next/link"
import { chipData } from "@/lib/content/chips"
import ChipGateSimulator from "@/components/chips/chip-gate-simulator"

export default function ChipPage({
  params
}: {
  params: { slug: string }
}) {
  const chip = chipData[params.slug]

  if (!chip) {
    return (
      <section className="mx-auto max-w-6xl px-6 py-12">
        <h1 className="text-3xl font-bold">Chip not found</h1>
        <p className="mt-4 text-slate-300">This chip has not been added yet.</p>
        <Link href="/chips" className="mt-6 inline-block rounded-xl bg-cyan-400 px-4 py-2 text-slate-950">
          Back to Chip Library
        </Link>
      </section>
    )
  }

  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-3xl font-bold">{chip.name}</h1>
          <p className="mt-2 text-slate-300">{chip.title}</p>
          <p className="mt-4 max-w-3xl text-slate-400">{chip.description}</p>
        </div>

        <Link
          href="/simulator"
          className="rounded-xl bg-cyan-400 px-4 py-2 text-slate-950"
        >
          Open in Simulator
        </Link>
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h2 className="text-xl font-semibold">Pin Diagram</h2>

          <div className="mt-6 flex justify-center overflow-x-auto">
            <div className="flex rounded-xl border border-white/10 bg-slate-950 p-6">
              <div className="flex flex-col justify-between pr-6 text-sm text-slate-300">
                {chip.pinsLeft.map((pin) => (
                  <div key={pin} className="flex items-center gap-2">
                    <span>{pin}</span>
                    <div className="h-px w-6 bg-white/20" />
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-center rounded-lg border border-white/10 bg-slate-800 px-8 py-12">
                <div className="text-center">
                  <p className="text-sm text-slate-400">IC</p>
                  <p className="text-xl font-bold">{chip.name}</p>
                </div>
              </div>

              <div className="flex flex-col justify-between pl-6 text-sm text-slate-300">
                {chip.pinsRight.map((pin) => (
                  <div key={pin} className="flex items-center gap-2">
                    <div className="h-px w-6 bg-white/20" />
                    <span>{pin}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h2 className="text-xl font-semibold">Truth Table</h2>

          <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
            <table className="w-full border-collapse text-left text-sm">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-4 py-3">A</th>
                  {chip.simulatorType !== "NOT" && <th className="px-4 py-3">B</th>}
                  <th className="px-4 py-3">Y</th>
                </tr>
              </thead>
              <tbody>
                {chip.truthTable.map((row, i) => (
                  <tr key={i} className="border-t border-white/10">
                    <td className="px-4 py-3">{row.A}</td>
                    {chip.simulatorType !== "NOT" && <td className="px-4 py-3">{row.B}</td>}
                    <td className="px-4 py-3">{row.Y}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="mt-10">
        <ChipGateSimulator type={chip.simulatorType} />
      </div>

      {params.slug === "7400" && (
        <div className="mt-10 rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h2 className="text-xl font-semibold">CMOS NAND Explanation</h2>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-cyan-400/20 bg-cyan-400/5 p-4">
              <h3 className="font-semibold text-cyan-300">Pull-Up Network</h3>
              <p className="mt-2 text-sm text-slate-300">
                PMOS transistors are connected in parallel. If either input is LOW,
                the output is pulled HIGH.
              </p>
            </div>

            <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-4">
              <h3 className="font-semibold text-emerald-300">Pull-Down Network</h3>
              <p className="mt-2 text-sm text-slate-300">
                NMOS transistors are connected in series. The output is pulled LOW
                only when both inputs are HIGH.
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
