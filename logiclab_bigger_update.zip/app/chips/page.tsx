
import Link from 'next/link'
import { chipData } from '@/lib/content/chips'

export default function ChipsPage() {
  const chips = Object.values(chipData)

  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="text-3xl font-bold">Chip Library</h1>
      <p className="mt-3 text-slate-300">
        Explore logic chips with definitions, truth tables, pin diagrams, and simple simulators.
      </p>

      <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {chips.map((chip) => (
          <Link
            key={chip.name}
            href={`/chips/${chip.name}`}
            className="rounded-2xl border border-white/10 bg-slate-900 p-5 hover:bg-slate-800"
          >
            <h2 className="text-xl font-semibold">{chip.name}</h2>
            <p className="mt-2 text-slate-300">{chip.title}</p>
          </Link>
        ))}
      </div>
    </section>
  )
}
