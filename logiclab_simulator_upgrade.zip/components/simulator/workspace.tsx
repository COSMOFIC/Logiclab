
'use client'

import { useEffect, useMemo, useState } from 'react'

type GateType = 'NOT' | 'AND' | 'OR' | 'NAND' | 'XOR'

function computeOutput(type: GateType, a: number, b: number) {
  switch (type) {
    case 'NOT':
      return a === 1 ? 0 : 1
    case 'AND':
      return a === 1 && b === 1 ? 1 : 0
    case 'OR':
      return a === 1 || b === 1 ? 1 : 0
    case 'NAND':
      return a === 1 && b === 1 ? 0 : 1
    case 'XOR':
      return a !== b ? 1 : 0
    default:
      return 0
  }
}

const chipToGate: Record<string, GateType> = {
  '7400': 'NAND',
  '7404': 'NOT',
  '7408': 'AND',
  '7432': 'OR',
  '7486': 'XOR'
}

export default function SimulatorWorkspace({
  chip
}: {
  chip?: string | null
}) {
  const [gate, setGate] = useState<GateType>('NAND')
  const [a, setA] = useState(0)
  const [b, setB] = useState(0)

  useEffect(() => {
    if (chip && chipToGate[chip]) {
      setGate(chipToGate[chip])
      setA(0)
      setB(0)
    }
  }, [chip])

  const y = useMemo(() => computeOutput(gate, a, b), [gate, a, b])

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <h2 className="text-2xl font-semibold">Logic Playground</h2>
            <p className="mt-2 text-sm text-slate-400">
              Choose a gate, toggle inputs, and observe the output instantly.
            </p>
          </div>

          <div className="rounded-xl border border-cyan-400/20 bg-cyan-400/5 px-4 py-3 text-sm text-cyan-200">
            Active gate: <span className="font-semibold">{gate}</span>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div className="rounded-2xl border border-white/10 bg-slate-900 p-5">
          <h3 className="text-lg font-semibold">Choose Gate</h3>

          <div className="mt-4 grid gap-3">
            {(['NOT', 'AND', 'OR', 'NAND', 'XOR'] as GateType[]).map((item) => (
              <button
                key={item}
                onClick={() => setGate(item)}
                className={`rounded-xl border px-4 py-3 text-left transition ${
                  gate === item
                    ? 'border-cyan-400 bg-cyan-400 text-slate-950'
                    : 'border-white/10 bg-slate-950 text-white hover:bg-slate-800'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-900 p-6">
          <h3 className="text-lg font-semibold">Interactive Simulation</h3>

          <div className="mt-6 grid gap-6 md:grid-cols-3">
            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-sm text-slate-400">Input A</p>
              <button
                onClick={() => setA(a ? 0 : 1)}
                className="mt-4 w-full rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950"
              >
                A = {a}
              </button>
            </div>

            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-sm text-slate-400">Input B</p>
              <button
                onClick={() => setB(b ? 0 : 1)}
                disabled={gate === 'NOT'}
                className={`mt-4 w-full rounded-xl px-4 py-3 font-semibold ${
                  gate === 'NOT'
                    ? 'cursor-not-allowed bg-slate-800 text-slate-500'
                    : 'bg-cyan-400 text-slate-950'
                }`}
              >
                {gate === 'NOT' ? 'Not used' : `B = ${b}`}
              </button>
            </div>

            <div className="rounded-xl border border-white/10 bg-slate-950 p-4">
              <p className="text-sm text-slate-400">Output</p>
              <div className="mt-4 flex items-center justify-between rounded-xl border border-white/10 bg-slate-900 px-4 py-3">
                <span className="font-semibold">Y = {y}</span>
                <div
                  className={`h-4 w-4 rounded-full ${
                    y === 1 ? 'bg-emerald-400 shadow-lg shadow-emerald-400/40' : 'bg-slate-600'
                  }`}
                />
              </div>
            </div>
          </div>

          <div className="mt-8 rounded-2xl border border-white/10 bg-slate-950 p-5">
            <div className="flex items-center justify-between gap-4">
              <div className="rounded-xl border border-white/10 bg-slate-900 px-5 py-4 text-center min-w-[80px]">
                <p className="text-xs text-slate-500">A</p>
                <p className="mt-1 text-xl font-bold">{a}</p>
              </div>

              <div className="flex-1 rounded-2xl border border-cyan-400/20 bg-cyan-400/5 px-6 py-5 text-center">
                <p className="text-sm text-cyan-200">Gate</p>
                <p className="mt-1 text-2xl font-bold">{gate}</p>
              </div>

              <div className="rounded-xl border border-white/10 bg-slate-900 px-5 py-4 text-center min-w-[80px]">
                <p className="text-xs text-slate-500">B</p>
                <p className="mt-1 text-xl font-bold">{gate === 'NOT' ? '-' : b}</p>
              </div>
            </div>

            <div className="mt-5 flex justify-center">
              <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 px-8 py-4 text-center">
                <p className="text-sm text-emerald-300">Output</p>
                <p className="mt-1 text-2xl font-bold">Y = {y}</p>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-white/10 bg-slate-950 p-4">
            <p className="text-sm text-slate-400">Current rule</p>
            <p className="mt-2 text-sm text-slate-300">
              {gate === 'NOT' && 'NOT outputs the opposite of input A.'}
              {gate === 'AND' && 'AND outputs 1 only when both A and B are 1.'}
              {gate === 'OR' && 'OR outputs 1 when at least one input is 1.'}
              {gate === 'NAND' && 'NAND outputs 0 only when both A and B are 1.'}
              {gate === 'XOR' && 'XOR outputs 1 when the inputs are different.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
