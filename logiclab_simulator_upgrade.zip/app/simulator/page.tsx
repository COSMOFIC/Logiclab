
import SimulatorWorkspace from '@/components/simulator/workspace'

export default function SimulatorPage({
  searchParams
}: {
  searchParams?: { chip?: string }
}) {
  const chip = searchParams?.chip ?? null

  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Circuit Simulator</h1>
        <p className="mt-3 text-slate-300">
          Explore logic gates interactively. You can also open this page from a chip page to preload a matching gate.
        </p>
      </div>

      <SimulatorWorkspace chip={chip} />
    </section>
  )
}
